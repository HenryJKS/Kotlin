package com.example.checkpointpratica

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.checkpointpratica.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private var binding: ActivityMainBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =ActivityMainBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_main)

        binding?.radio1?.setOnClickListener {
            makeVisible()
        }

        binding?.radio2?.setOnClickListener {
            makeVisible()
        }

        binding?.radio3?.setOnClickListener {
            makeVisible()
        }

    }



    private fun makeVisible () {
        binding?.radio1?.visibility = View.GONE
        binding?.radio2?.visibility = View.GONE
        binding?.radio3?.visibility = View.GONE

    }

}